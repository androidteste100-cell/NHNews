import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import fs from "node:fs";
import nodePath from "node:path";
//#region src/pages/api/download.ts
var download_exports = /* @__PURE__ */ __exportAll({
	GET: () => GET,
	prerender: () => false
});
var GET = async () => {
	const zipPath = nodePath.join(process.cwd(), "public", "portal-noticias.zip");
	if (!fs.existsSync(zipPath)) return new Response("Arquivo ZIP não encontrado.", { status: 404 });
	const fileBuffer = fs.readFileSync(zipPath);
	return new Response(fileBuffer, {
		status: 200,
		headers: {
			"Content-Type": "application/zip",
			"Content-Disposition": "attachment; filename=\"portal-noticias.zip\"",
			"Content-Length": fileBuffer.length.toString(),
			"Cache-Control": "no-cache"
		}
	});
};
//#endregion
//#region \0virtual:astro:page:src/pages/api/download@_@ts
var page = () => download_exports;
//#endregion
export { page };
