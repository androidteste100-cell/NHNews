import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { i as verifyAdminPassword, n as getAdminSessionToken, t as ADMIN_COOKIE_NAME } from "./adminAuth_B-R4ipv7.mjs";
//#region src/pages/api/admin/auth.ts
var auth_exports = /* @__PURE__ */ __exportAll({
	DELETE: () => DELETE,
	POST: () => POST,
	prerender: () => false
});
var POST = async ({ request, cookies }) => {
	try {
		const { password } = await request.json();
		if (!password) return new Response(JSON.stringify({ error: "Informe a senha de administrador." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!verifyAdminPassword(password)) return new Response(JSON.stringify({ error: "Senha de acesso incorreta." }), {
			status: 401,
			headers: { "Content-Type": "application/json" }
		});
		cookies.set(ADMIN_COOKIE_NAME, getAdminSessionToken(), {
			path: "/",
			httpOnly: true,
			secure: process.env.NODE_ENV === "production",
			sameSite: "lax",
			maxAge: 604800
		});
		return new Response(JSON.stringify({ success: true }), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Erro ao processar autenticação." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
};
var DELETE = async ({ cookies }) => {
	cookies.delete(ADMIN_COOKIE_NAME, { path: "/" });
	return new Response(JSON.stringify({ success: true }), {
		status: 200,
		headers: { "Content-Type": "application/json" }
	});
};
//#endregion
//#region \0virtual:astro:page:src/pages/api/admin/auth@_@ts
var page = () => auth_exports;
//#endregion
export { page };
