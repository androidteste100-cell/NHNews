import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { A as renderTemplate, N as addAttribute, T as Fragment, j as maybeRenderHead, w as renderComponent, z as createAstro } from "./sequence_ze54tiZJ.mjs";
import { t as createComponent } from "./compiler_u7PmK8a0.mjs";
import { n as $$AdBanner, t as $$Layout } from "./Layout_BBs83w43.mjs";
import { c as isSupabaseConnected, l as isSupabaseTableMissing, o as getNoticiasByCategory, s as getRecentNoticias } from "./supabase_DLaYiq5D.mjs";
import { t as $$NewsCard } from "./NewsCard_B2l6wcMv.mjs";
//#region src/pages/index.astro
var pages_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Index,
	file: () => $$file,
	prerender: () => false,
	url: () => ""
});
createAstro("http://localhost:3000");
var $$Index = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Index;
	Astro.response.headers.set("Cache-Control", "no-cache, no-store, must-revalidate");
	const [noticias, noticiasEconomiaRaw, noticiasTecnologiaRaw, noticiasMercadosRaw, noticiasCienciaRaw] = await Promise.all([
		getRecentNoticias(30),
		getNoticiasByCategory("Economia", 6),
		getNoticiasByCategory("Tecnologia", 6),
		getNoticiasByCategory("Mercados", 6),
		getNoticiasByCategory("Ciência", 6)
	]);
	const manchetePrincipal = noticias[0];
	const destaquesLaterais = noticias.slice(1, 5);
	const maisLidas = noticias.slice(0, 5);
	const maisRecentes = noticias.slice(5);
	const hasSupabase = isSupabaseConnected();
	const tableMissing = isSupabaseTableMissing();
	const plantaoTitulo = manchetePrincipal?.titulo || "Portal de Notícias atualizado em tempo real";
	const plantaoResumo = manchetePrincipal?.resumo || "";
	const plantaoSlug = manchetePrincipal?.slug && manchetePrincipal.slug.trim().replace(/^\/+|\/+$/g, "") || (manchetePrincipal?.id ? `noticia-${manchetePrincipal.id}` : "recente");
	const plantaoImagem = manchetePrincipal?.imagem && manchetePrincipal.imagem.trim() || "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?q=80&w=1200&auto=format&fit=crop";
	const plantaoCategoria = manchetePrincipal?.categoria || "Geral";
	const usedThematicIds = /* @__PURE__ */ new Set();
	function getCategoryItems(rawList, categoriaNome, fallbackList) {
		const selected = [];
		for (const item of rawList || []) {
			const key = item.id || item.slug;
			if (!usedThematicIds.has(key)) {
				selected.push(item);
				usedThematicIds.add(key);
			}
			if (selected.length === 3) break;
		}
		if (selected.length < 3) {
			for (const item of fallbackList) if (item.categoria?.toLowerCase() === categoriaNome.toLowerCase()) {
				const key = item.id || item.slug;
				if (!usedThematicIds.has(key)) {
					selected.push(item);
					usedThematicIds.add(key);
				}
				if (selected.length === 3) break;
			}
		}
		if (selected.length < 3) for (const item of fallbackList) {
			const key = item.id || item.slug;
			if (!usedThematicIds.has(key)) {
				selected.push(item);
				usedThematicIds.add(key);
			}
			if (selected.length === 3) break;
		}
		return selected;
	}
	const secoesTematicas = [
		{
			titulo: "Economia & Inovação",
			categoria: "Economia",
			href: "/categoria/Economia",
			noticias: getCategoryItems(noticiasEconomiaRaw, "Economia", noticias)
		},
		{
			titulo: "Tecnologia & Inteligência Artificial",
			categoria: "Tecnologia",
			href: "/categoria/Tecnologia",
			noticias: getCategoryItems(noticiasTecnologiaRaw, "Tecnologia", noticias)
		},
		{
			titulo: "Mercados & Negócios",
			categoria: "Mercados",
			href: "/categoria/Mercados",
			noticias: getCategoryItems(noticiasMercadosRaw, "Mercados", noticias)
		},
		{
			titulo: "Ciência & Sustentabilidade",
			categoria: "Ciência",
			href: "/categoria/Ciência",
			noticias: getCategoryItems(noticiasCienciaRaw, "Ciência", noticias)
		}
	];
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "Portal de Notícias — Informação e Cobertura em Tempo Real",
		"description": "Portal de notícias com cobertura jornalística de tecnologia, economia, mercados, ciência, inovação e sustentabilidade."
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5"><div id="plantao" class="mb-6 bg-white border border-neutral-200 rounded-2xl p-4 sm:py-3 sm:px-5 shadow-xs transition-all hover:border-neutral-300"><div class="sm:hidden space-y-3"><div class="flex items-center justify-between gap-2"><div class="flex items-center gap-2"><span class="inline-flex items-center gap-1.5 bg-[#dd3333] text-white text-xs font-black uppercase px-3 py-1 rounded-full shadow-xs tracking-wider"><span class="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>PLANTÃO 24H</span><span class="text-[11px] font-bold uppercase bg-neutral-100 text-neutral-800 px-2.5 py-1 rounded-full border border-neutral-200/60">${plantaoCategoria}</span></div><div class="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-600"><span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span><span>AO VIVO</span></div></div><a${addAttribute(`/noticia/${plantaoSlug}`, "href")} class="block relative w-full aspect-[16/9] overflow-hidden rounded-xl bg-neutral-100 border border-neutral-200 group focus:outline-none"${addAttribute(`Ler matéria completa: ${plantaoTitulo}`, "aria-label")}><img${addAttribute(plantaoImagem, "src")}${addAttribute(plantaoTitulo, "alt")} class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" width="600" height="338" loading="eager" decoding="sync"><div class="absolute top-2.5 left-2.5 bg-black/75 text-white text-[10px] font-bold uppercase px-2.5 py-1 rounded-md backdrop-blur-xs">ÚLTIMA HORA</div></a><div><h2 class="text-base font-bold text-neutral-900 leading-snug group-hover:text-[#dd3333] transition-colors"><a${addAttribute(`/noticia/${plantaoSlug}`, "href")} class="hover:text-[#dd3333] transition-colors focus:outline-none">${plantaoTitulo}</a></h2>${plantaoResumo && renderTemplate`<p class="text-xs text-neutral-600 leading-relaxed mt-2 line-clamp-3">${plantaoResumo}</p>`}</div><div class="pt-2.5 border-t border-neutral-100 flex items-center justify-between text-xs"><span class="text-[11px] text-neutral-500 font-medium">Cobertura contínua em tempo real</span><a${addAttribute(`/noticia/${plantaoSlug}`, "href")} class="font-bold text-[#dd3333] hover:underline flex items-center gap-1 shrink-0"><span>Ler notícia completa</span><span>→</span></a></div></div><div class="hidden sm:flex sm:items-center justify-between gap-4"><div class="flex items-center gap-3 min-w-0 flex-1"><span class="inline-flex items-center gap-1.5 bg-[#dd3333] text-white text-[11px] font-black uppercase px-3 py-1 rounded-full shadow-xs tracking-wider shrink-0"><span class="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>PLANTÃO</span><span class="text-neutral-300 font-bold">|</span><a${addAttribute(`/noticia/${plantaoSlug}`, "href")} class="shrink-0 group block"${addAttribute(`Ler notícia: ${plantaoTitulo}`, "aria-label")}><img${addAttribute(plantaoImagem, "src")}${addAttribute(plantaoTitulo, "alt")} class="w-12 h-12 rounded-xl object-cover border border-neutral-200 group-hover:scale-105 transition-transform" width="48" height="48" loading="eager"></a><div class="min-w-0 flex-1"><div class="text-[10px] font-bold uppercase text-[#dd3333] tracking-wide mb-0.5">${plantaoCategoria}</div><a${addAttribute(`/noticia/${plantaoSlug}`, "href")} class="font-bold text-sm text-neutral-900 hover:text-[#dd3333] transition-colors leading-snug line-clamp-1 block"${addAttribute(plantaoTitulo, "title")}>${plantaoTitulo}</a></div></div><div class="flex items-center gap-4 shrink-0 text-xs"><div class="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-600"><span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span><span>TEMPO REAL</span></div><a${addAttribute(`/noticia/${plantaoSlug}`, "href")} class="text-xs font-bold text-[#dd3333] hover:underline flex items-center gap-1 shrink-0"><span>Ver notícia completa</span><span>→</span></a></div></div></div>${!hasSupabase && renderTemplate`<div class="mb-6 p-4 rounded-2xl bg-white border border-neutral-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs"><div class="flex items-center gap-2.5"><span${addAttribute(`w-2.5 h-2.5 rounded-full ${tableMissing ? "bg-amber-500 animate-pulse" : "bg-[#dd3333] animate-ping"} shrink-0`, "class")}></span><span class="text-neutral-900 font-medium">${tableMissing ? renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`<strong>Conexão Supabase Detectada:</strong> A tabela <code>public.noticias</code> ainda não foi criada no seu banco. Execute o script <code>supabase/schema.sql</code> no SQL Editor do painel Supabase para sincronizar suas matérias.` })}` : renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`<strong>Modo de Demonstração Ativo:</strong> Exibindo dados de teste com layout CPG na cor branca. Configure <code>PUBLIC_SUPABASE_URL</code> e <code>PUBLIC_SUPABASE_ANON_KEY</code> no <code>.env</code> para sincronizar.` })}`}</span></div><span class="font-mono text-[10px] font-bold uppercase bg-neutral-900 text-white px-3 py-1.5 rounded-full shrink-0">${tableMissing ? "AÇÃO: EXECUTAR SCHEMA.SQL" : "STATUS: PRONTO PARA PRODUÇÃO"}</span></div>`}${manchetePrincipal ? renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`<section class="grid grid-cols-1 lg:grid-cols-[minmax(0,1.3fr)_1fr] gap-4 sm:gap-5 mb-8" aria-labelledby="heading-hero-cpg"><h1 id="heading-hero-cpg" class="sr-only">Destaques Principais do Portal de Notícias</h1><div class="w-full hidden sm:block">${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": manchetePrincipal,
		"variant": "featured",
		"priority": true,
		"class": "h-full"
	})}</div>${destaquesLaterais.length > 0 && renderTemplate`<div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">${destaquesLaterais.map((item) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": item,
		"variant": "lateral",
		"class": "h-full"
	})}`)}</div>`}</section><section class="my-8 flex justify-center" aria-label="Espaço Publicitário Central"><div class="w-full max-w-[728px] bg-white border border-neutral-200 rounded-2xl p-2 shadow-xs">${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "header",
		"customClass": "!my-0"
	})}</div></section>${secoesTematicas.map((secao, idx) => secao.noticias.length > 0 && renderTemplate`<section class="mb-10"${addAttribute(`Seção ${secao.titulo}`, "aria-label")}><div class="flex items-center justify-between border-b-2 border-neutral-200 pb-3 mb-6"><h2 class="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight flex items-center gap-2.5"><span class="w-2.5 h-6 bg-[#dd3333] rounded-full inline-block"></span>${secao.titulo}</h2><a${addAttribute(secao.href, "href")} class="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-neutral-700 hover:text-[#dd3333] transition-colors group">Mais artigos <span class="group-hover:translate-x-1 transition-transform">→</span></a></div><div class="grid grid-cols-1 md:grid-cols-3 gap-5">${secao.noticias.map((item) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": item,
		"variant": "standard",
		"class": "h-full"
	})}`)}</div>${idx === 1 && renderTemplate`<div class="my-8 flex justify-center" aria-label="Espaço Publicitário Intermediário"><div class="w-full max-w-[728px] bg-white border border-neutral-200 rounded-2xl p-2 shadow-xs">${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "content",
		"customClass": "!my-0"
	})}</div></div>`}</section>`)}<section class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12"><div class="lg:col-span-2"><div class="flex items-center justify-between border-b-2 border-neutral-200 pb-3 mb-6"><h3 class="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight flex items-center gap-2.5"><span class="w-2.5 h-6 bg-blue-600 rounded-full inline-block"></span>Mais Recentes</h3><span class="text-[11px] font-mono font-bold bg-neutral-100 text-neutral-700 border border-neutral-200 px-3 py-1 rounded-full">FEED CONTÍNUO</span></div><div class="space-y-4">${maisRecentes.length > 0 ? maisRecentes.map((item) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": item,
		"variant": "compact"
	})}`) : noticias.slice(0, 4).map((item) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": item,
		"variant": "compact"
	})}`)}</div></div><div class="lg:col-span-1 space-y-6"><div class="bg-white rounded-2xl p-5 border border-neutral-200 shadow-xs"><div class="flex items-center justify-between border-b border-neutral-100 pb-3 mb-2"><h3 class="text-base font-bold text-neutral-900 flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-[#dd3333] inline-block"></span>Mais Lidas da Semana</h3><span class="text-[10px] font-bold uppercase text-[#dd3333] tracking-wider">EM ALTA</span></div><div class="divide-y divide-neutral-100">${maisLidas.map((item, index) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": item,
		"variant": "ranked",
		"rank": index + 1
	})}`)}</div></div><div class="bg-white text-neutral-900 rounded-2xl p-5 sm:p-6 border-2 border-neutral-200 shadow-xs relative overflow-hidden"><div class="relative z-10"><span class="inline-block bg-[#dd3333] text-white text-[10px] font-black uppercase px-3 py-1 rounded-full mb-3 tracking-wider shadow-2xs">NOTIFICAÇÕES VIP</span><h4 class="text-base sm:text-lg font-bold leading-tight mb-2 text-neutral-950">Receba notícias urgentes no seu WhatsApp ou Telegram</h4><p class="text-xs text-neutral-600 leading-relaxed mb-4">Acompanhe os principais furos jornalísticos, análises econômicas e vagas de emprego diretamente no celular.</p><a href="/admin" class="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-full bg-neutral-900 hover:bg-[#dd3333] text-white font-bold text-xs transition-colors shadow-xs"><span>Acessar Notificações</span><span>→</span></a></div></div><div class="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs flex flex-col items-center justify-center"><div class="w-full flex items-center justify-between text-[10px] font-bold uppercase text-neutral-400 mb-3 pb-2 border-b border-neutral-100"><span>Espaço Publicitário</span><span class="bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded-full border border-neutral-200">300x250</span></div>${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "sidebar",
		"customClass": "!my-0"
	})}</div></div></section>` })}` : renderTemplate`<div class="text-center py-20 bg-white rounded-2xl border border-neutral-200 p-8 shadow-xs"><h2 class="text-2xl font-bold text-neutral-900 mb-2">Nenhuma notícia publicada no momento</h2><p class="text-gray-500 max-w-md mx-auto text-sm">O pipeline de automação está configurado para alimentar a tabela <code>noticias</code> do Supabase automaticamente.</p></div>`}</div>` })}`;
}, "/app/applet/src/pages/index.astro", void 0);
var $$file = "/app/applet/src/pages/index.astro";
//#endregion
//#region \0virtual:astro:page:src/pages/index@_@astro
var page = () => pages_exports;
//#endregion
export { page };
