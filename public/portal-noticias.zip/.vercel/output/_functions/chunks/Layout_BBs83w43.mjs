import { A as renderTemplate, D as renderSlot, L as unescapeHTML, M as renderHead, N as addAttribute, T as Fragment, j as maybeRenderHead, w as renderComponent, z as createAstro } from "./sequence_ze54tiZJ.mjs";
import { t as createComponent } from "./compiler_u7PmK8a0.mjs";
//#region src/components/AdBanner.astro
createAstro("http://localhost:3000");
var $$AdBanner = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$AdBanner;
	const { slotType, customClass = "", adId } = Astro.props;
	const minHeightClass = {
		"header": "min-h-[90px] max-w-[728px] md:min-h-[90px]",
		"in-article": "min-h-[250px] max-w-[336px] sm:max-w-[728px] md:min-h-[280px]",
		"sidebar": "min-h-[600px] max-w-[300px]",
		"footer": "min-h-[90px] max-w-[728px]"
	}[slotType] || "min-h-[90px]";
	return renderTemplate`${maybeRenderHead($$result)}<aside${addAttribute(`ad-slot-wrapper w-full my-6 flex flex-col items-center justify-center overflow-hidden transition-opacity ${customClass}`, "class")}${addAttribute(`Espaço publicitário ${slotType}`, "aria-label")}><div${addAttribute(`ad-container relative w-full flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-400 dark:border-neutral-600 bg-gray-100 dark:bg-neutral-900/60 text-neutral-400 dark:text-neutral-500 p-3 ${minHeightClass}`, "class")}${addAttribute(slotType, "data-slot-type")}${addAttribute(adId ? `ad-${adId}` : void 0, "id")}><div class="ad-label-wrapper w-full text-right mb-1"><span class="text-[10px] uppercase tracking-widest text-gray-400 dark:text-neutral-500 font-bold select-none">Publicidade</span></div><div class="ad-content-slot w-full h-full flex flex-1 items-center justify-center text-center">${renderSlot($$result, $$slots["default"], renderTemplate`<div class="flex flex-col items-center justify-center p-4"><svg class="w-6 h-6 mb-1 text-gray-400 dark:text-neutral-500 opacity-60 shrink-0" width="24" height="24" style="width: 24px; height: 24px; max-width: 24px; max-height: 24px;" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"></path></svg><span class="text-xs font-mono font-semibold uppercase text-gray-600 dark:text-neutral-300">Espaço Reservado (${slotType})</span><span class="text-[10px] font-mono text-gray-400 dark:text-neutral-500 mt-0.5">Sem impacto em CLS</span></div>`)}</div></div></aside>`;
}, "/app/applet/src/components/AdBanner.astro", void 0);
//#endregion
//#region src/components/Header.astro
createAstro("http://localhost:3000");
var $$Header = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Header;
	const navCategories = [
		{
			name: "Início",
			href: "/"
		},
		{
			name: "Tecnologia",
			href: "/categoria/Tecnologia"
		},
		{
			name: "Economia",
			href: "/categoria/Economia"
		},
		{
			name: "Mercados",
			href: "/categoria/Mercados"
		},
		{
			name: "Ciência",
			href: "/categoria/Ciência"
		},
		{
			name: "Cidades",
			href: "/categoria/Cidades"
		},
		{
			name: "Segurança",
			href: "/categoria/Segurança"
		}
	];
	const trendingTags = [
		{
			name: "Petróleo & Energia",
			href: "/categoria/Economia"
		},
		{
			name: "Inteligência Artificial",
			href: "/categoria/Tecnologia"
		},
		{
			name: "Dólar & Ações",
			href: "/categoria/Mercados"
		}
	];
	const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR", {
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric"
	});
	const currentPath = Astro.url.pathname;
	const isCurrent = (href) => {
		if (href === "/") return currentPath === "/";
		return currentPath.startsWith(href);
	};
	return renderTemplate`${maybeRenderHead($$result)}<header class="w-full bg-white border-b border-neutral-200 shadow-xs"><div class="w-full bg-white border-b border-neutral-100 flex items-center justify-center min-h-[90px] px-4 py-2"><div class="w-full max-w-[728px]">${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "header",
		"customClass": "!my-0"
	})}</div></div><div class="border-b border-neutral-100 text-[11px] text-neutral-500 py-1.5 px-4 sm:px-8 bg-neutral-50/90"><div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2"><div class="flex items-center gap-2 capitalize font-medium"><span class="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span><span>${currentDate}</span></div><div class="flex items-center gap-4"><a href="/rss.xml" class="hover:text-[#dd3333] transition-colors flex items-center gap-1 font-semibold" target="_blank" rel="noopener noreferrer"><svg class="w-3.5 h-3.5 text-amber-500 shrink-0" width="14" height="14" style="width: 14px; height: 14px; max-width: 14px; max-height: 14px;" fill="currentColor" viewBox="0 0 24 24"><path d="M6.18 15.64a2.18 2.18 0 0 1 2.18 2.18C8.36 19 7.38 20 6.18 20C5 20 4 19 4 17.82a2.18 2.18 0 0 1 2.18-2.18M4 4.44A15.56 15.56 0 0 1 19.56 20h-2.83A12.73 12.73 0 0 0 4 7.27V4.44m0 5.66a9.9 9.9 0 0 1 9.9 9.9h-2.83A7.07 7.07 0 0 0 4 12.93V10.1z"></path></svg>RSS FEED</a><a href="/sitemap.xml" class="hover:text-[#dd3333] transition-colors font-semibold" target="_blank" rel="noopener noreferrer">SITEMAP</a><span class="text-neutral-300">|</span><span class="font-mono text-[10px] uppercase text-neutral-400">SSR EDGE VERCEL</span></div></div></div><div class="max-w-7xl mx-auto px-4 sm:px-8 py-4 flex items-center justify-between gap-4 bg-white"><div class="flex items-center gap-4"><a href="/" class="group flex items-center gap-2"><div class="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tighter uppercase italic text-neutral-950">PORTAL<span class="text-[#dd3333]">NOTÍCIAS</span></div></a><span class="hidden sm:inline-block text-[10px] font-bold text-neutral-400 uppercase tracking-widest pl-3 border-l border-neutral-200">Jornalismo em Tempo Real</span></div><div class="flex items-center gap-2.5 sm:gap-3"><a href="/admin" class="text-xs font-mono font-bold bg-white text-neutral-900 border-2 border-neutral-200 px-4 py-1.5 rounded-full hover:border-[#dd3333] hover:text-[#dd3333] transition-all flex items-center gap-2 shadow-xs" title="Acessar Painel de Redação e Gerenciamento"><span class="w-2 h-2 rounded-full bg-[#dd3333]"></span><span>PAINEL ADMIN</span></a><div class="hidden sm:flex text-xs font-mono font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 px-3.5 py-1.5 rounded-full tracking-tight items-center gap-2 shadow-xs"><span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span><span>LIVE: SSR OK</span></div></div></div><div class="sticky top-0 z-40 bg-[#111827] text-white border-t-2 border-[#dd3333] border-b border-neutral-900 shadow-md"><div class="max-w-7xl mx-auto px-4 sm:px-8 py-2.5 flex items-center justify-between gap-4"><nav class="hidden lg:flex items-center gap-2" aria-label="Menu Superior de Categorias">${navCategories.map((cat) => {
		const active = isCurrent(cat.href);
		return renderTemplate`<a${addAttribute(cat.href, "href")}${addAttribute(`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-200 ${active ? "bg-[#dd3333] text-white shadow-md border-2 border-[#dd3333] scale-105" : "bg-neutral-800/90 text-neutral-200 border border-neutral-700 hover:border-[#dd3333] hover:text-white hover:bg-[#dd3333] shadow-2xs"}`, "class")}>${cat.name}</a>`;
	})}</nav><div class="hidden xl:flex items-center gap-2 text-xs font-medium"><span class="text-[10px] font-mono font-bold text-[#dd3333] uppercase">Tópicos:</span>${trendingTags.map((tag) => renderTemplate`<a${addAttribute(tag.href, "href")} class="px-2.5 py-1 rounded-full bg-neutral-800 hover:bg-[#dd3333] text-neutral-300 hover:text-white border border-neutral-700/80 hover:border-[#dd3333] text-[11px] font-semibold transition-all">#${tag.name}</a>`)}</div><div class="lg:hidden w-full overflow-x-auto scrollbar-none py-0.5"><nav class="flex items-center gap-2 whitespace-nowrap" aria-label="Menu Superior Mobile">${navCategories.map((cat) => {
		const active = isCurrent(cat.href);
		return renderTemplate`<a${addAttribute(cat.href, "href")}${addAttribute(`px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shrink-0 transition-all ${active ? "bg-[#dd3333] text-white shadow-xs border border-[#dd3333]" : "bg-neutral-800 text-neutral-200 border border-neutral-700 hover:border-[#dd3333] hover:text-white"}`, "class")}>${cat.name}</a>`;
	})}</nav></div></div></div></header>`;
}, "/app/applet/src/components/Header.astro", void 0);
//#endregion
//#region src/components/Footer.astro
var $$Footer = createComponent(($$result, $$props, $$slots) => {
	const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
	const categories = [
		"Tecnologia",
		"Economia",
		"Mercados",
		"Ciência",
		"Cidades",
		"Segurança"
	];
	return renderTemplate`${maybeRenderHead($$result)}<footer id="menu-inferior" class="w-full bg-[#111827] text-neutral-200 border-t-4 border-[#dd3333] mt-16 pt-10 pb-16 sm:pb-8 shadow-md"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="mb-10 bg-neutral-900/90 border-2 border-neutral-800 rounded-3xl p-5 sm:p-7 shadow-xs"><div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 mb-5 border-b border-neutral-800"><div><span class="inline-block bg-[#dd3333] text-white text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full mb-1.5 shadow-2xs">MENU INFERIOR PRINCIPAL</span><h2 class="text-base sm:text-lg font-black uppercase italic text-white flex items-center gap-2"><span>Navegação Rápida por Editorias</span></h2></div><button onclick="window.scrollTo({top: 0, behavior: 'smooth'})" class="self-start md:self-auto inline-flex items-center gap-2 px-4 py-2 rounded-full border-2 border-neutral-700 hover:border-[#dd3333] bg-neutral-800 hover:bg-[#dd3333] text-white text-xs font-bold uppercase transition-all shadow-xs cursor-pointer" title="Rolar de volta ao topo da página"><span>↑ Voltar ao Topo</span></button></div><div class="flex flex-wrap items-center gap-2.5"><a href="/" class="px-4 py-2 rounded-full bg-[#dd3333] text-white font-black text-xs uppercase tracking-wider shadow-xs transition-colors flex items-center gap-1.5 hover:bg-red-700"><span class="w-1.5 h-1.5 rounded-full bg-white"></span><span>Início</span></a>${categories.map((cat) => renderTemplate`<a${addAttribute(`/categoria/${cat}`, "href")} class="px-4 py-2 rounded-full bg-neutral-800 hover:bg-[#dd3333] text-neutral-200 hover:text-white border border-neutral-700 hover:border-[#dd3333] font-bold text-xs uppercase tracking-wider shadow-2xs transition-all hover:scale-102">${cat}</a>`)}<a href="/admin" class="px-4 py-2 rounded-full bg-neutral-800 text-neutral-200 border-2 border-neutral-700 hover:border-[#dd3333] hover:text-white font-mono font-bold text-xs uppercase tracking-wider shadow-xs transition-colors flex items-center gap-1.5 ml-auto"><span class="w-2 h-2 rounded-full bg-[#dd3333]"></span><span>Painel Admin</span></a><a href="/api/download" download="portal-noticias.zip" class="px-4 py-2 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider shadow-xs transition-colors flex items-center gap-1.5"><span>📦 Baixar ZIP</span></a></div></div><div class="mb-10 flex justify-center"><div class="w-full max-w-[728px] bg-neutral-900 border border-neutral-800 rounded-2xl p-2 shadow-xs">${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "footer",
		"customClass": "!my-0"
	})}</div></div><div class="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-neutral-800"><div class="md:col-span-2"><div class="flex items-center gap-2 mb-3"><div class="text-2xl font-black tracking-tighter uppercase italic text-white">PORTAL<span class="text-[#dd3333]">NOTÍCIAS</span></div></div><p class="text-sm text-neutral-400 max-w-md leading-relaxed">Portal de notícias automatizado de última geração com Astro SSR, Supabase e Vercel. Cobertura em tempo real com integridade de dados, otimização para Core Web Vitals e conformidade total com Google News.</p><div class="mt-4 font-mono text-[10px] text-neutral-500 uppercase">PUBLICAÇÃO CONTÍNUA VIA SUPABASE & VERCEL SSR EDGE</div></div><div><h3 class="text-xs font-bold text-white uppercase tracking-widest mb-4 flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-[#dd3333]"></span><span>Categorias</span></h3><ul class="space-y-2 text-xs font-bold uppercase tracking-wider text-neutral-300">${categories.map((cat) => renderTemplate`<li><a${addAttribute(`/categoria/${cat}`, "href")} class="hover:text-[#dd3333] transition-colors flex items-center gap-1"><span class="text-neutral-500">›</span><span>${cat}</span></a></li>`)}</ul></div><div><h3 class="text-xs font-bold text-white uppercase tracking-widest mb-4 flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-blue-500"></span><span>Transparência & Dados</span></h3><ul class="space-y-2 text-xs font-bold uppercase tracking-wider text-neutral-300"><li><a href="/rss.xml" class="hover:text-[#dd3333] transition-colors flex items-center gap-1.5" target="_blank" rel="noopener noreferrer"><span>Feed RSS (Google News)</span></a></li><li><a href="/sitemap.xml" class="hover:text-[#dd3333] transition-colors" target="_blank" rel="noopener noreferrer">Mapa do Site (XML)</a></li><li><a href="/robots.txt" class="hover:text-[#dd3333] transition-colors" target="_blank" rel="noopener noreferrer">Diretrizes de Rastreio (robots.txt)</a></li><li><a href="https://supabase.com" class="hover:text-[#dd3333] transition-colors" target="_blank" rel="noopener noreferrer">Infraestrutura Supabase</a></li><li><a href="/api/download" download="portal-noticias.zip" class="hover:text-emerald-400 transition-colors flex items-center gap-1.5 font-bold" title="Baixar código-fonte completo em arquivo ZIP"><span>📦 Baixar Projeto (.ZIP)</span></a></li></ul></div></div><div class="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400 font-medium"><p>© ${currentYear} Portal de Notícias. Todos os direitos reservados.</p><div class="flex items-center gap-3 font-mono text-[11px] uppercase"><span class="bg-neutral-800 text-neutral-300 px-3 py-1 rounded-full border border-neutral-700">ASTRO SSR</span><span class="bg-neutral-800 text-neutral-300 px-3 py-1 rounded-full border border-neutral-700">TAILWIND</span><span class="bg-neutral-800 text-neutral-300 px-3 py-1 rounded-full border border-neutral-700">SUPABASE</span></div></div></div><aside class="md:hidden fixed bottom-3 left-3 right-3 z-50 bg-[#111827]/95 backdrop-blur-md border-2 border-neutral-700 rounded-full shadow-2xl px-3 py-2 flex items-center justify-around text-[10px] font-bold uppercase tracking-wider text-neutral-200" aria-label="Barra de Navegação Rápida Inferior Mobile"><a href="/" class="flex flex-col items-center gap-0.5 hover:text-[#dd3333] transition-colors"><svg class="w-4 h-4 shrink-0" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg><span>Início</span></a><a href="#menu-inferior" class="flex flex-col items-center gap-0.5 hover:text-[#dd3333] transition-colors"><svg class="w-4 h-4 shrink-0" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h7"></path></svg><span>Editorias</span></a><a href="/#plantao" class="flex flex-col items-center gap-0.5 text-[#dd3333]"><span class="w-2 h-2 rounded-full bg-[#dd3333] animate-ping"></span><span>Plantão</span></a><a href="/admin" class="flex flex-col items-center gap-0.5 hover:text-[#dd3333] transition-colors"><svg class="w-4 h-4 shrink-0" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg><span>Admin</span></a><button onclick="window.scrollTo({top: 0, behavior: 'smooth'})" class="flex flex-col items-center gap-0.5 hover:text-[#dd3333] transition-colors cursor-pointer"><svg class="w-4 h-4 shrink-0" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"></path></svg><span>Topo</span></button></aside></footer>`;
}, "/app/applet/src/components/Footer.astro", void 0);
//#endregion
//#region src/components/SEO.astro
createAstro("http://localhost:3000");
var $$SEO = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$SEO;
	const { title, description, image = "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?q=80&w=1200&auto=format&fit=crop", canonicalURL = Astro.url.href, article, breadcrumbs } = Astro.props;
	const siteName = "Portal de Notícias";
	const formattedTitle = title.includes(siteName) ? title : `${title} | ${siteName}`;
	const newsArticleSchema = article ? {
		"@context": "https://schema.org",
		"@type": "NewsArticle",
		headline: title,
		description,
		image: [image],
		datePublished: article.publishedTime,
		dateModified: article.modifiedTime || article.publishedTime,
		author: [{
			"@type": "Person",
			name: article.author
		}],
		publisher: {
			"@type": "Organization",
			name: siteName,
			logo: {
				"@type": "ImageObject",
				url: new URL("/favicon.svg", Astro.site || Astro.url).href
			}
		},
		mainEntityOfPage: {
			"@type": "WebPage",
			"@id": canonicalURL
		},
		articleSection: article.section
	} : null;
	const breadcrumbsSchema = breadcrumbs && breadcrumbs.length > 0 ? {
		"@context": "https://schema.org",
		"@type": "BreadcrumbList",
		itemListElement: breadcrumbs.map((crumb, index) => ({
			"@type": "ListItem",
			position: index + 1,
			name: crumb.name,
			item: crumb.item
		}))
	} : null;
	const websiteSchema = !article ? {
		"@context": "https://schema.org",
		"@type": "NewsMediaOrganization",
		name: siteName,
		url: Astro.site || Astro.url.origin,
		potentialAction: {
			"@type": "SearchAction",
			target: `${Astro.site || Astro.url.origin}/busca?q={search_term_string}`,
			"query-input": "required name=search_term_string"
		}
	} : null;
	return renderTemplate`<!-- Metatags Globais --><title>${formattedTitle}</title><meta name="title"${addAttribute(formattedTitle, "content")}><meta name="description"${addAttribute(description, "content")}><link rel="canonical"${addAttribute(canonicalURL, "href")}><meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"><!-- Open Graph / Facebook --><meta property="og:type"${addAttribute(article ? "article" : "website", "content")}><meta property="og:url"${addAttribute(canonicalURL, "content")}><meta property="og:title"${addAttribute(formattedTitle, "content")}><meta property="og:description"${addAttribute(description, "content")}><meta property="og:image"${addAttribute(image, "content")}><meta property="og:site_name"${addAttribute(siteName, "content")}><meta property="og:locale" content="pt_BR">${article && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`<meta property="article:published_time"${addAttribute(article.publishedTime, "content")}>${article.modifiedTime && renderTemplate`<meta property="article:modified_time"${addAttribute(article.modifiedTime, "content")}>`}<meta property="article:author"${addAttribute(article.author, "content")}><meta property="article:section"${addAttribute(article.section, "content")}>` })}`}<!-- Twitter Cards --><meta name="twitter:card" content="summary_large_image"><meta name="twitter:url"${addAttribute(canonicalURL, "content")}><meta name="twitter:title"${addAttribute(formattedTitle, "content")}><meta name="twitter:description"${addAttribute(description, "content")}><meta name="twitter:image"${addAttribute(image, "content")}><!-- Structured Data (JSON-LD) para SEO e Google News -->${newsArticleSchema && renderTemplate`<script type="application/ld+json">${unescapeHTML(JSON.stringify(newsArticleSchema))}<\/script>`}${breadcrumbsSchema && renderTemplate`<script type="application/ld+json">${unescapeHTML(JSON.stringify(breadcrumbsSchema))}<\/script>`}${websiteSchema && renderTemplate`<script type="application/ld+json">${unescapeHTML(JSON.stringify(websiteSchema))}<\/script>`}`;
}, "/app/applet/src/components/SEO.astro", void 0);
//#endregion
//#region src/layouts/Layout.astro
createAstro("http://localhost:3000");
var $$Layout = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Layout;
	const { title, description, image, canonicalURL, article, breadcrumbs } = Astro.props;
	return renderTemplate`<html lang="pt-BR" class="scroll-smooth"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="manifest" href="/manifest.webmanifest"><meta name="theme-color" content="#0284c7"><!-- Otimizações de Conexão para Core Web Vitals --><link rel="preconnect" href="https://images.unsplash.com"><link rel="dns-prefetch" href="https://images.unsplash.com"><!-- SEO Component (Metatags, OpenGraph, Twitter, Schema.org) -->${renderComponent($$result, "SEO", $$SEO, {
		"title": title,
		"description": description,
		"image": image,
		"canonicalURL": canonicalURL,
		"article": article,
		"breadcrumbs": breadcrumbs
	})}${renderHead($$result)}</head><body class="bg-white text-slate-900 min-h-screen flex flex-col antialiased selection:bg-[#dd3333] selection:text-white font-sans">${renderComponent($$result, "Header", $$Header, {})}<main class="flex-1 w-full bg-white">${renderSlot($$result, $$slots["default"])}</main>${renderComponent($$result, "Footer", $$Footer, {})}</body></html>`;
}, "/app/applet/src/layouts/Layout.astro", void 0);
//#endregion
export { $$AdBanner as n, $$Layout as t };
