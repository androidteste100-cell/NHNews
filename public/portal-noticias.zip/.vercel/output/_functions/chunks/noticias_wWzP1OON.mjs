import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { r as isAdminAuthenticated } from "./adminAuth_B-R4ipv7.mjs";
import { d as updateNoticia, n as deleteNoticia, r as getAllNoticiasAdmin, t as createNoticia, u as toggleNoticiaStatus } from "./supabase_DLaYiq5D.mjs";
//#region src/pages/api/admin/noticias.ts
var noticias_exports = /* @__PURE__ */ __exportAll({
	DELETE: () => DELETE,
	GET: () => GET,
	PATCH: () => PATCH,
	POST: () => POST,
	PUT: () => PUT,
	prerender: () => false
});
function generateSlug(text) {
	return text.toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().replace(/[^a-z0-9\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
/**
* GET: Lista todas as notícias (painel admin)
*/
var GET = async ({ request, cookies }) => {
	if (!isAdminAuthenticated(cookies)) return new Response(JSON.stringify({ error: "Não autorizado." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	try {
		const noticias = await getAllNoticiasAdmin();
		return new Response(JSON.stringify({ noticias }), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Erro ao carregar notícias." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
};
/**
* POST: Cria uma nova notícia
*/
var POST = async ({ request, cookies }) => {
	if (!isAdminAuthenticated(cookies)) return new Response(JSON.stringify({ error: "Não autorizado." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	try {
		const body = await request.json();
		const { titulo, resumo, conteudo, categoria, imagem, autor, publicado } = body;
		let { slug } = body;
		if (!titulo?.trim()) return new Response(JSON.stringify({ error: "O título da notícia é obrigatório." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!resumo?.trim()) return new Response(JSON.stringify({ error: "O resumo da notícia é obrigatório." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!conteudo?.trim()) return new Response(JSON.stringify({ error: "O conteúdo da notícia é obrigatório." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!categoria?.trim()) return new Response(JSON.stringify({ error: "A categoria da notícia é obrigatória." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!imagem?.trim()) return new Response(JSON.stringify({ error: "A URL da imagem é obrigatória." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!slug?.trim()) slug = generateSlug(titulo);
		else slug = generateSlug(slug);
		const payload = {
			titulo: titulo.trim(),
			slug,
			resumo: resumo.trim(),
			conteudo: conteudo.trim(),
			categoria: categoria.trim(),
			imagem: imagem.trim(),
			autor: autor?.trim() || "Redação",
			publicado: publicado !== void 0 ? Boolean(publicado) : true
		};
		const { data, error } = await createNoticia(payload);
		if (error) return new Response(JSON.stringify({ error }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		return new Response(JSON.stringify({
			success: true,
			noticia: data
		}), {
			status: 201,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Erro ao processar criação de notícia." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
};
/**
* PUT: Atualiza notícia existente
*/
var PUT = async ({ request, cookies }) => {
	if (!isAdminAuthenticated(cookies)) return new Response(JSON.stringify({ error: "Não autorizado." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	try {
		const body = await request.json();
		const { id, titulo, resumo, conteudo, categoria, imagem, autor, publicado } = body;
		let { slug } = body;
		if (!id) return new Response(JSON.stringify({ error: "ID da notícia não informado." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (!titulo?.trim()) return new Response(JSON.stringify({ error: "O título da notícia é obrigatório." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		if (slug?.trim()) slug = generateSlug(slug);
		else slug = generateSlug(titulo);
		const payload = {
			titulo: titulo.trim(),
			slug,
			resumo: resumo?.trim() || "",
			conteudo: conteudo?.trim() || "",
			categoria: categoria?.trim() || "Geral",
			imagem: imagem?.trim() || "",
			autor: autor?.trim() || "Redação",
			publicado: publicado !== void 0 ? Boolean(publicado) : true
		};
		const { data, error } = await updateNoticia(id, payload);
		if (error) return new Response(JSON.stringify({ error }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		return new Response(JSON.stringify({
			success: true,
			noticia: data
		}), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Erro ao atualizar notícia." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
};
/**
* DELETE: Exclui uma notícia
*/
var DELETE = async ({ request, cookies }) => {
	if (!isAdminAuthenticated(cookies)) return new Response(JSON.stringify({ error: "Não autorizado." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	try {
		const id = new URL(request.url).searchParams.get("id");
		if (!id) return new Response(JSON.stringify({ error: "ID da notícia é obrigatório." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		const { success, error } = await deleteNoticia(id);
		if (!success || error) return new Response(JSON.stringify({ error: error || "Não foi possível excluir a notícia." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		return new Response(JSON.stringify({ success: true }), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Erro ao excluir notícia." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
};
/**
* PATCH: Alterna status de publicação
*/
var PATCH = async ({ request, cookies }) => {
	if (!isAdminAuthenticated(cookies)) return new Response(JSON.stringify({ error: "Não autorizado." }), {
		status: 401,
		headers: { "Content-Type": "application/json" }
	});
	try {
		const { id, publicado } = await request.json();
		if (!id || publicado === void 0) return new Response(JSON.stringify({ error: "Parâmetros inválidos." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		const { success, error } = await toggleNoticiaStatus(id, Boolean(publicado));
		if (!success || error) return new Response(JSON.stringify({ error: error || "Falha ao alterar status." }), {
			status: 400,
			headers: { "Content-Type": "application/json" }
		});
		return new Response(JSON.stringify({ success: true }), {
			status: 200,
			headers: { "Content-Type": "application/json" }
		});
	} catch (err) {
		return new Response(JSON.stringify({ error: err?.message || "Erro ao alterar status da notícia." }), {
			status: 500,
			headers: { "Content-Type": "application/json" }
		});
	}
};
//#endregion
//#region \0virtual:astro:page:src/pages/api/admin/noticias@_@ts
var page = () => noticias_exports;
//#endregion
export { page };
