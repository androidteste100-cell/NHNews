import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { i as getAllSlugs } from "./supabase_DLaYiq5D.mjs";
//#region src/pages/sitemap.xml.ts
var sitemap_xml_exports = /* @__PURE__ */ __exportAll({ GET: () => GET });
var GET = async ({ site, url }) => {
	const baseUrl = site ? site.origin : url.origin;
	const slugs = await getAllSlugs();
	const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">
  ${[
		"",
		"/categoria/Tecnologia",
		"/categoria/Economia",
		"/categoria/Mercados",
		"/categoria/Ciência",
		"/categoria/Cidades",
		"/categoria/Segurança"
	].map((route) => `
  <url>
    <loc>${baseUrl}${route}</loc>
    <changefreq>hourly</changefreq>
    <priority>${route === "" ? "1.0" : "0.8"}</priority>
  </url>`).join("")}
  ${slugs.map((item) => `
  <url>
    <loc>${baseUrl}/noticia/${item.slug}</loc>
    <lastmod>${new Date(item.updated_at || Date.now()).toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>`).join("")}
</urlset>`;
	return new Response(sitemapXml.trim(), {
		status: 200,
		headers: {
			"Content-Type": "application/xml; charset=utf-8",
			"Cache-Control": "public, max-age=3600, s-maxage=7200"
		}
	});
};
//#endregion
//#region \0virtual:astro:page:src/pages/sitemap.xml@_@ts
var page = () => sitemap_xml_exports;
//#endregion
export { page };
