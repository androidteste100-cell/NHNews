import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { A as renderTemplate, L as unescapeHTML, N as addAttribute, j as maybeRenderHead, w as renderComponent, z as createAstro } from "./sequence_ze54tiZJ.mjs";
import { t as createComponent } from "./compiler_u7PmK8a0.mjs";
import { n as $$AdBanner, t as $$Layout } from "./Layout_BBs83w43.mjs";
import { a as getNoticiaBySlug, s as getRecentNoticias } from "./supabase_DLaYiq5D.mjs";
import { t as $$NewsCard } from "./NewsCard_B2l6wcMv.mjs";
//#region src/lib/sanitize.ts
/**
* Sanitizador de HTML nativo, ultra-resiliente e de alta performance para artigos jornalísticos.
* Não depende de bibliotecas externas (como sanitize-html), eliminando qualquer falha
* de ESM/CJS interop no ambiente Vercel Serverless.
*/
var DANGEROUS_TAGS_REGEX = /<(script|style|iframe|object|embed|applet|meta|link|base)[^>]*>[\s\S]*?<\/\1>|<(script|style|iframe|object|embed|applet|meta|link|base)[^>]*\/?>/gi;
var EVENT_HANDLERS_REGEX = /\s+on[a-z0-9_]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi;
var JAVASCRIPT_PROTOCOLS_REGEX = /(?:href|src)\s*=\s*(?:"javascript:[^"]*"|'javascript:[^']*'|javascript:[^\s>]+)/gi;
/**
* Sanitiza o HTML bruto garantindo proteção contra XSS e conformidade com os padrões de segurança.
*/
function sanitizeArticleHtml(dirtyHtml) {
	if (!dirtyHtml || typeof dirtyHtml !== "string") return "";
	try {
		let clean = dirtyHtml;
		clean = clean.replace(/<!--\s*AD_SLOT_1\s*-->/g, "<div data-ad-placeholder=\"1\"></div>").replace(/<!--\s*AD_SLOT_2\s*-->/g, "<div data-ad-placeholder=\"2\"></div>").replace(/<!--\s*AD_SLOT_FOOTER\s*-->/g, "<div data-ad-placeholder=\"footer\"></div>");
		clean = clean.replace(DANGEROUS_TAGS_REGEX, "");
		clean = clean.replace(EVENT_HANDLERS_REGEX, "");
		clean = clean.replace(JAVASCRIPT_PROTOCOLS_REGEX, "href=\"#\"");
		clean = clean.replace(/<a\s+([^>]*?)>/gi, (match, attrs) => {
			let updated = attrs;
			if (!/rel\s*=/i.test(updated)) updated += " rel=\"noopener noreferrer nofollow\"";
			if (!/target\s*=/i.test(updated) && /href\s*=\s*["']?https?:\/\//i.test(updated)) updated += " target=\"_blank\"";
			return `<a ${updated}>`;
		});
		clean = clean.replace(/<img\s+([^>]*?)>/gi, (match, attrs) => {
			let updated = attrs;
			if (!/loading\s*=/i.test(updated)) updated += " loading=\"lazy\"";
			if (!/decoding\s*=/i.test(updated)) updated += " decoding=\"async\"";
			return `<img ${updated}>`;
		});
		return clean;
	} catch (err) {
		console.warn("[Sanitize Aviso] Erro na sanitização de HTML, retornando conteúdo seguro:", err);
		return dirtyHtml.replace(DANGEROUS_TAGS_REGEX, "");
	}
}
//#endregion
//#region src/pages/noticia/[slug].astro
var _slug__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Slug,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("http://localhost:3000");
var $$Slug = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Slug;
	Astro.response.headers.set("Cache-Control", "no-cache, no-store, must-revalidate");
	const { slug } = Astro.params;
	if (!slug) return Astro.redirect("/404");
	const noticia = await getNoticiaBySlug(slug);
	if (!noticia) return Astro.redirect("/404");
	const sanitizedContent = sanitizeArticleHtml(noticia.conteudo || "");
	const safeTitulo = noticia.titulo?.trim() || "Notícia em Atualização";
	const safeResumo = noticia.resumo?.trim() || "";
	const safeAutor = noticia.autor?.trim() || "Redação";
	const safeCategoria = noticia.categoria?.trim() || "Geral";
	const safeImagem = noticia.imagem?.trim() || "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?q=80&w=1200&auto=format&fit=crop";
	const autorInitial = (safeAutor.charAt(0) || "R").toUpperCase();
	const finalHtml = sanitizedContent.replace(/(?:<!--\s*AD_SLOT_1\s*-->|<div data-ad-placeholder="1"><\/div>)/g, `
  <aside class="ad-slot-wrapper my-8 flex flex-col items-center justify-center not-prose" aria-label="Espaço publicitário intermediário 1">
    <div class="w-full flex flex-col items-center justify-center rounded-xl border border-dashed border-neutral-300 bg-neutral-50 p-3 min-h-[250px] max-w-[728px] text-center">
      <span class="text-[10px] uppercase font-semibold tracking-wider text-neutral-400 self-end mb-2 select-none">Publicidade</span>
      <div class="flex flex-col items-center justify-center p-4 text-neutral-400">
        <svg class="w-6 h-6 mb-1 opacity-40 shrink-0" width="24" height="24" style="width: 24px; height: 24px; max-width: 24px; max-height: 24px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
        <span class="text-xs font-medium text-neutral-500">Publicidade Programática</span>
        <span class="text-[11px] text-neutral-400 mt-0.5">Espaço in-article reservado • Sem CLS</span>
      </div>
    </div>
  </aside>
`).replace(/(?:<!--\s*AD_SLOT_2\s*-->|<div data-ad-placeholder="2"><\/div>)/g, `
  <aside class="ad-slot-wrapper my-8 flex flex-col items-center justify-center not-prose" aria-label="Espaço publicitário intermediário 2">
    <div class="w-full flex flex-col items-center justify-center rounded-xl border border-dashed border-neutral-300 bg-neutral-50 p-3 min-h-[250px] max-w-[728px] text-center">
      <span class="text-[10px] uppercase font-semibold tracking-wider text-neutral-400 self-end mb-2 select-none">Publicidade</span>
      <div class="flex flex-col items-center justify-center p-4 text-neutral-400">
        <svg class="w-6 h-6 mb-1 opacity-40 shrink-0" width="24" height="24" style="width: 24px; height: 24px; max-width: 24px; max-height: 24px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
        <span class="text-xs font-medium text-neutral-500">Anúncio Afiliados / AdSense</span>
        <span class="text-[11px] text-neutral-400 mt-0.5">Espaço in-article reservado • Sem CLS</span>
      </div>
    </div>
  </aside>
`).replace(/(?:<!--\s*AD_SLOT_FOOTER\s*-->|<div data-ad-placeholder="footer"><\/div>)/g, `
  <aside class="ad-slot-wrapper my-8 flex flex-col items-center justify-center not-prose" aria-label="Espaço publicitário de fechamento">
    <div class="w-full flex flex-col items-center justify-center rounded-xl border border-dashed border-neutral-300 bg-neutral-50 p-3 min-h-[90px] max-w-[728px] text-center">
      <span class="text-[10px] uppercase font-semibold tracking-wider text-neutral-400 self-end mb-1 select-none">Publicidade</span>
      <span class="text-xs font-medium text-neutral-500">Espaço Reservado de Encerramento (Footer Article)</span>
    </div>
  </aside>
`);
	const recomendadas = (await getRecentNoticias(5)).filter((n) => n.slug !== slug).slice(0, 3);
	const rawDate = noticia.created_at ? new Date(noticia.created_at) : /* @__PURE__ */ new Date();
	const validDate = isNaN(rawDate.getTime()) ? /* @__PURE__ */ new Date() : rawDate;
	const publishedDate = validDate.toLocaleDateString("pt-BR", {
		day: "2-digit",
		month: "long",
		year: "numeric"
	});
	const publishedTime = validDate.toLocaleTimeString("pt-BR", {
		hour: "2-digit",
		minute: "2-digit"
	});
	const isoDate = validDate.toISOString();
	const siteUrl = Astro.site?.origin || Astro.url.origin;
	const canonicalUrl = `${siteUrl}/noticia/${noticia.slug || slug}`;
	const breadcrumbs = [
		{
			name: "Início",
			item: siteUrl
		},
		{
			name: safeCategoria,
			item: `${siteUrl}/categoria/${encodeURIComponent(safeCategoria)}`
		},
		{
			name: safeTitulo,
			item: canonicalUrl
		}
	];
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": safeTitulo,
		"description": safeResumo,
		"image": safeImagem,
		"canonicalURL": canonicalUrl,
		"article": {
			publishedTime: isoDate,
			author: safeAutor,
			section: safeCategoria
		},
		"breadcrumbs": breadcrumbs
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><!-- Breadcrumb visual de navegação --><nav aria-label="Breadcrumb" class="mb-6 text-xs text-neutral-500 flex items-center gap-2 flex-wrap"><a href="/" class="hover:text-[#dd3333] transition-colors">Início</a><span class="text-neutral-300">/</span><a${addAttribute(`/categoria/${safeCategoria}`, "href")} class="hover:text-[#dd3333] transition-colors font-medium">${safeCategoria}</a><span class="text-neutral-300">/</span><span class="text-neutral-800 truncate max-w-xs sm:max-w-md">${safeTitulo}</span></nav><!-- Layout Grid com Artigo e Sidebar --><div class="grid grid-cols-1 lg:grid-cols-12 gap-8"><!-- Corpo Principal do Artigo (8 colunas) --><article class="lg:col-span-8 bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 shadow-xs"><!-- Cabeçalho do Artigo --><header class="mb-8"><div class="mb-3"><a${addAttribute(`/categoria/${safeCategoria}`, "href")} class="inline-block bg-[#dd3333] text-white text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow-xs">${safeCategoria}</a></div><h1 class="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight uppercase italic text-neutral-950 leading-[1.2] mb-4">${safeTitulo}</h1>${safeResumo && renderTemplate`<p class="text-base sm:text-lg text-neutral-600 leading-relaxed font-sans font-normal mb-6">${safeResumo}</p>`}<!-- Metadados do Autor e Data --><div class="flex items-center justify-between py-3 border-y border-neutral-200 text-xs text-neutral-500"><div class="flex items-center gap-3"><div class="w-8 h-8 rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold uppercase text-xs">${autorInitial}</div><div><span class="font-bold text-neutral-900 block uppercase text-[11px]">${safeAutor}</span><span class="text-[10px] text-neutral-400">REDAÇÃO ESPECIAL</span></div></div><div class="text-right"><time${addAttribute(isoDate, "datetime")} class="block font-bold text-neutral-900 text-[11px]">${publishedDate}</time><span class="text-[10px] text-neutral-400">ATUALIZADO ÀS ${publishedTime}</span></div></div></header><!-- Imagem Principal de Destaque com Aspect Ratio Fixo e LCP Otimizado --><figure class="mb-8 rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-100"><img${addAttribute(safeImagem, "src")}${addAttribute(safeTitulo, "alt")} width="1200" height="675" loading="eager" fetchpriority="high" decoding="sync" class="w-full aspect-[16/9] object-cover"><figcaption class="text-[10px] font-mono text-neutral-500 p-2 text-right uppercase bg-neutral-50 border-t border-neutral-200">FOTO: DIVULGAÇÃO / AGÊNCIA DE NOTÍCIAS</figcaption></figure><!-- Conteúdo do Artigo Sanitizado com Anúncios Injetados --><div class="prose prose-neutral max-w-none text-base leading-relaxed text-neutral-800 [&amp;&gt;p]:mb-6 [&amp;&gt;h2]:text-xl [&amp;&gt;h2]:font-bold [&amp;&gt;h2]:mt-8 [&amp;&gt;h2]:mb-3 [&amp;&gt;blockquote]:border-l-4 [&amp;&gt;blockquote]:border-[#dd3333] [&amp;&gt;blockquote]:pl-4 [&amp;&gt;blockquote]:italic [&amp;&gt;blockquote]:text-neutral-700">${unescapeHTML(finalHtml)}</div><!-- Compartilhamento e Tags de Fechamento --><div class="mt-12 pt-6 border-t border-neutral-200 flex items-center justify-between"><div class="text-xs text-neutral-500 font-mono">PORTAL DE NOTÍCIAS • VERCEL SSR EDGE</div><a href="/" class="text-xs font-bold uppercase tracking-wider text-[#dd3333] hover:underline transition-colors flex items-center gap-1"><span>← Página Inicial</span></a></div></article><!-- Coluna Lateral (4 colunas) --><aside class="lg:col-span-4 space-y-6" aria-label="Publicidade e Notícias Relacionadas"><!-- Banner de Sidebar Bento --><div class="sticky top-6 space-y-6"><div class="bg-white border border-neutral-200 rounded-2xl p-4 shadow-xs flex flex-col items-center justify-center">${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "sidebar",
		"customClass": "!my-0"
	})}</div><!-- Bloco de Notícias Relacionadas -->${recomendadas.length > 0 && renderTemplate`<div class="bg-white border border-neutral-200 rounded-2xl p-5 shadow-xs"><div class="flex items-center justify-between pb-3 mb-3 border-b border-neutral-200"><h3 class="text-sm font-bold text-neutral-900 uppercase tracking-tight flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-[#dd3333] inline-block"></span>Leia Também</h3><span class="text-[10px] font-bold text-[#dd3333] uppercase">Recomendadas</span></div><div class="divide-y divide-neutral-100">${recomendadas.map((rec) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": rec,
		"variant": "compact"
	})}`)}</div></div>`}</div></aside></div></div>` })}`;
}, "/app/applet/src/pages/noticia/[slug].astro", void 0);
var $$file = "/app/applet/src/pages/noticia/[slug].astro";
var $$url = "/noticia/[slug]";
//#endregion
//#region \0virtual:astro:page:src/pages/noticia/[slug]@_@astro
var page = () => _slug__exports;
//#endregion
export { page };
