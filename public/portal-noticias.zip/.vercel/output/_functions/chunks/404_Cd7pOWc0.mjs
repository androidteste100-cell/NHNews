import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { A as renderTemplate, j as maybeRenderHead, w as renderComponent } from "./sequence_ze54tiZJ.mjs";
import { t as createComponent } from "./compiler_u7PmK8a0.mjs";
import { t as $$Layout } from "./Layout_BBs83w43.mjs";
//#region src/pages/404.astro
var _404_exports = /* @__PURE__ */ __exportAll({
	default: () => $$404,
	file: () => $$file,
	url: () => $$url
});
var $$404 = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "Página Não Encontrada (404) — Portal de Notícias",
		"description": "A página que você procura não foi encontrada ou foi movida."
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<div class="max-w-3xl mx-auto px-4 py-24 text-center"><span class="text-7xl font-black text-sky-600 font-serif block mb-4">404</span><h1 class="text-3xl sm:text-4xl font-extrabold text-neutral-900 dark:text-white tracking-tight mb-4">Página não encontrada</h1><p class="text-base text-neutral-600 dark:text-neutral-400 mb-8 max-w-md mx-auto leading-relaxed">A notícia ou página que você tentou acessar pode ter sido movida, atualizada ou o link digitado está incorreto.</p><div class="flex flex-col sm:flex-row items-center justify-center gap-4"><a href="/" class="w-full sm:w-auto bg-sky-600 hover:bg-sky-700 text-white font-semibold text-sm px-6 py-3 rounded-lg shadow-sm transition-colors">Voltar para a Página Inicial</a><a href="/categoria/Tecnologia" class="w-full sm:w-auto bg-neutral-200 hover:bg-neutral-300 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-semibold text-sm px-6 py-3 rounded-lg transition-colors">Ver Últimas Notícias</a></div></div>` })}`;
}, "/app/applet/src/pages/404.astro", void 0);
var $$file = "/app/applet/src/pages/404.astro";
var $$url = "/404";
//#endregion
//#region \0virtual:astro:page:src/pages/404@_@astro
var page = () => _404_exports;
//#endregion
export { page };
