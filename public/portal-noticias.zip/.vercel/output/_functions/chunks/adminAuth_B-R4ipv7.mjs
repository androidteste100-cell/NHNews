//#region src/lib/adminAuth.ts
var ADMIN_PASSWORD = typeof process !== "undefined" && process.env.ADMIN_PASSWORD || "014789";
var ADMIN_COOKIE_NAME = "portal_admin_token";
var SESSION_TOKEN = Buffer.from(`portal_session_${ADMIN_PASSWORD}`).toString("base64");
function verifyAdminPassword(password) {
	if (!password) return false;
	return password.trim() === ADMIN_PASSWORD.trim();
}
function getAdminSessionToken() {
	return SESSION_TOKEN;
}
function isAdminAuthenticated(cookies) {
	try {
		let token;
		if ("get" in cookies && typeof cookies.get === "function") token = cookies.get(ADMIN_COOKIE_NAME)?.value;
		else if (cookies instanceof Request) {
			const match = (cookies.headers.get("cookie") || "").match(new RegExp(`${ADMIN_COOKIE_NAME}=([^;]+)`));
			token = match ? match[1] : void 0;
		}
		return token === SESSION_TOKEN;
	} catch {
		return false;
	}
}
//#endregion
export { verifyAdminPassword as i, getAdminSessionToken as n, isAdminAuthenticated as r, ADMIN_COOKIE_NAME as t };
