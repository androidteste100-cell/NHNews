import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { A as renderTemplate, T as Fragment, j as maybeRenderHead, w as renderComponent, z as createAstro } from "./sequence_ze54tiZJ.mjs";
import { t as createComponent } from "./compiler_u7PmK8a0.mjs";
import { n as $$AdBanner, t as $$Layout } from "./Layout_BBs83w43.mjs";
import { o as getNoticiasByCategory } from "./supabase_DLaYiq5D.mjs";
import { t as $$NewsCard } from "./NewsCard_B2l6wcMv.mjs";
//#region src/pages/categoria/[categoria].astro
var _categoria__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Categoria,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("http://localhost:3000");
var $$Categoria = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Categoria;
	Astro.response.headers.set("Cache-Control", "no-cache, no-store, must-revalidate");
	const { categoria } = Astro.params;
	if (!categoria) return Astro.redirect("/404");
	const noticias = await getNoticiasByCategory(categoria, 18);
	const siteUrl = Astro.site?.origin || Astro.url.origin;
	const canonicalUrl = `${siteUrl}/categoria/${encodeURIComponent(categoria)}`;
	const breadcrumbs = [{
		name: "Início",
		item: siteUrl
	}, {
		name: categoria,
		item: canonicalUrl
	}];
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": `Notícias sobre ${categoria}`,
		"description": `Confira todas as reportagens, notícias e análises sobre ${categoria} atualizadas em tempo real.`,
		"canonicalURL": canonicalUrl,
		"breadcrumbs": breadcrumbs
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6"><!-- Navegação Breadcrumb --><nav aria-label="Breadcrumb" class="mb-5 text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-2"><a href="/" class="hover:text-[#dd3333] transition-colors">Início</a><span class="text-neutral-300">/</span><span class="text-neutral-900">${categoria}</span></nav><!-- Título da Categoria --><div class="border-b-2 border-neutral-200 pb-3 mb-8 flex flex-col sm:flex-row sm:items-baseline justify-between gap-3"><div><h1 class="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight uppercase italic text-neutral-950 flex items-center gap-3"><span class="w-3 h-8 bg-[#dd3333] rounded-full inline-block"></span>${categoria}</h1><p class="text-xs sm:text-sm text-neutral-500 mt-1">Acompanhe os acontecimentos mais recentes e análises aprofundadas sobre ${categoria}.</p></div><span class="text-[10px] font-mono font-bold bg-neutral-900 text-white px-3 py-1.5 rounded-full uppercase shrink-0">${noticias.length} ${noticias.length === 1 ? "ARTIGO DISPONÍVEL" : "ARTIGOS DISPONÍVEIS"}</span></div>${noticias.length > 0 ? renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">${noticias.map((item, index) => renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "NewsCard", $$NewsCard, {
		"noticia": item,
		"variant": "standard"
	})}${index === 2 && renderTemplate`<div class="col-span-full my-4 flex justify-center"><div class="w-full max-w-[728px] bg-white border border-neutral-200 rounded-2xl p-2 shadow-xs">${renderComponent($$result, "AdBanner", $$AdBanner, {
		"slotType": "header",
		"customClass": "!my-0"
	})}</div></div>`}` })}`)}</div>` })}` : renderTemplate`<div class="text-center py-20 bg-white rounded-2xl border border-neutral-200 p-8 shadow-xs"><h2 class="text-xl font-bold text-neutral-900 mb-2">Nenhuma notícia encontrada nesta categoria</h2><p class="text-neutral-500 max-w-md mx-auto text-xs sm:text-sm mb-6">As matérias de ${categoria} serão publicadas automaticamente pelo fluxo de automação.</p><a href="/" class="inline-block bg-neutral-900 hover:bg-[#dd3333] text-white text-xs font-bold uppercase tracking-wider px-5 py-2.5 rounded-full transition-colors">Voltar para a Página Inicial</a></div>`}</div>` })}`;
}, "/app/applet/src/pages/categoria/[categoria].astro", void 0);
var $$file = "/app/applet/src/pages/categoria/[categoria].astro";
var $$url = "/categoria/[categoria]";
//#endregion
//#region \0virtual:astro:page:src/pages/categoria/[categoria]@_@astro
var page = () => _categoria__exports;
//#endregion
export { page };
